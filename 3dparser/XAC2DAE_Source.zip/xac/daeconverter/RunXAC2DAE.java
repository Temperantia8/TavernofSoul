package xac.daeconverter;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import javax.vecmath.Matrix4d;
import javax.vecmath.Vector3d;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class RunXAC2DAE {

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("No file was specified");

        } else {
            File xac_file = new File(args[0]);

            if (xac_file.exists()) {
                try {
                    BufferedInputStream input = new BufferedInputStream(new FileInputStream(xac_file));

                    XACData xac = new XACData(input);

                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder documentBuilder = factory.newDocumentBuilder();
                    Document document = documentBuilder.parse("./XAC_Template.dat");

                    Element root = document.getDocumentElement();

                    removeSpace(root);

                    Element lib_geo = (Element) root.getElementsByTagName("library_geometries").item(0);
                    Element geo_temp = (Element) lib_geo.getElementsByTagName("geometry").item(0);
                    Element poly_temp = (Element) geo_temp.getElementsByTagName("polylist").item(0);

                    Element node_mesh_temp = null;
                    Element node_armature_temp = null;
                    Element node_bone_temp = null;

                    Element visual_scene_tag = (Element) document.getElementsByTagName("visual_scene").item(0);
                    NodeList nodes = visual_scene_tag.getElementsByTagName("node");

                    for (int i = 0; i < nodes.getLength(); i++) {
                        Element node_tag = (Element) nodes.item(i);

                        if (node_tag.getAttribute("id").compareToIgnoreCase("Cube") == 0)
                            node_mesh_temp = node_tag;

                        if (node_tag.getAttribute("id").compareToIgnoreCase("Armature") == 0)
                            node_armature_temp = node_tag;

                        if (node_tag.getAttribute("id").compareToIgnoreCase("Bone000") == 0)
                            node_bone_temp = node_tag;
                    }

                    Objects.requireNonNull(node_bone_temp).getParentNode().removeChild(node_bone_temp);

                    Element lib_con_tag = (Element) root.getElementsByTagName("library_controllers").item(0);
                    Element controller_temp = (Element) lib_con_tag.getElementsByTagName("controller").item(0);
                    NodeList removers = poly_temp.getElementsByTagName("input");

                    for (int i_r = 0; i_r < removers.getLength(); i_r++) {
                        Element target = (Element) removers.item(i_r);
                        poly_temp.removeChild(target);
                    }

                    lib_geo.removeChild(geo_temp);

                    poly_temp.getParentNode().removeChild(poly_temp);

                    Objects.requireNonNull(node_mesh_temp).getParentNode().removeChild(node_mesh_temp);
                    Objects.requireNonNull(node_armature_temp).getParentNode().removeChild(node_armature_temp);

                    controller_temp.getParentNode().removeChild(controller_temp);

                    for (XACData.Chunk e_ch : xac.chunks) {
                        if (e_ch.chunk_type == 1) {
                            Element geo_tag = (Element) geo_temp.cloneNode(true);

                            if (e_ch.mesh_chunk.last_positions != null) {
                                XACData.Chunk.MeshChunk.VerticesAttribute e_att = e_ch.mesh_chunk.last_positions;
                                NodeList flo_poss = geo_tag.getElementsByTagName("float_array");

                                for (int m = 0; m < flo_poss.getLength(); m++) {
                                    Element flo_arr_tag = (Element) flo_poss.item(m);

                                    if (flo_arr_tag.getAttribute("id").compareToIgnoreCase("Cube-mesh-positions-array") == 0) {
                                        StringBuilder str_buf = new StringBuilder(e_att.new_positions.size() * 6);

                                        for (XACData.Chunk.MeshChunk.VerticesAttribute.NewPosition e_pos : e_att.new_positions)
                                            str_buf.append(e_pos.x).append(" ").append(e_pos.y).append(" ").append(-e_pos.z).append(" ");

                                        flo_arr_tag.setTextContent(str_buf.toString());
                                        flo_arr_tag.setAttribute("count", String.valueOf(e_att.new_positions.size() * 3));
                                    }
                                }

                                NodeList acce_poss = geo_tag.getElementsByTagName("accessor");

                                for (int n = 0; n < acce_poss.getLength(); n++) {
                                    Element acce_pos = (Element) acce_poss.item(n);

                                    if (acce_pos.getAttribute("source").compareToIgnoreCase("#Cube-mesh-positions-array") == 0)
                                        acce_pos.setAttribute("count", String.valueOf(e_att.new_positions.size()));
                                }
                            }

                            if (e_ch.mesh_chunk.last_normals != null) {
                                XACData.Chunk.MeshChunk.VerticesAttribute e_att = e_ch.mesh_chunk.last_normals;
                                NodeList flo_poss = geo_tag.getElementsByTagName("float_array");

                                for (int m = 0; m < flo_poss.getLength(); m++) {
                                    Element flo_arr_tag = (Element) flo_poss.item(m);

                                    if (flo_arr_tag.getAttribute("id").compareToIgnoreCase("Cube-mesh-normals-array") == 0) {
                                        if (e_att.normals != null) {
                                            StringBuilder str_buf = new StringBuilder(e_att.normals.length * 6);

                                            XACData.Chunk.MeshChunk.VerticesAttribute.Normal[] arrayOfNormal;

                                            for (int j = 0; j < (arrayOfNormal = e_att.normals).length; j++) {
                                                XACData.Chunk.MeshChunk.VerticesAttribute.Normal e_uv = arrayOfNormal[j];
                                                str_buf.append(-e_uv.n_x).append(" ").append(-e_uv.n_y).append(" ").append(e_uv.n_z).append(" ");
                                            }

                                            flo_arr_tag.setTextContent(str_buf.toString());
                                            flo_arr_tag.setAttribute("count", String.valueOf(e_att.normals.length * 3));
                                        }

                                        flo_arr_tag.setAttribute("id", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-normals-array");
                                    }
                                }

                                NodeList src_nor_tags = geo_tag.getElementsByTagName("source");

                                for (int n = 0; n < src_nor_tags.getLength(); n++) {
                                    Element src_nor_tag = (Element) src_nor_tags.item(n);

                                    if (src_nor_tag.getAttribute("id").compareToIgnoreCase("Cube-mesh-normals") == 0)
                                        src_nor_tag.setAttribute("id", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-normals");
                                }

                                NodeList acce_poss = geo_tag.getElementsByTagName("accessor");

                                for (int i1 = 0; i1 < acce_poss.getLength(); i1++) {
                                    Element acce_pos = (Element) acce_poss.item(i1);

                                    if (acce_pos.getAttribute("source").compareToIgnoreCase("#Cube-mesh-normals-array") == 0) {
                                        acce_pos.setAttribute("count", String.valueOf(e_att.normals.length));
                                        acce_pos.setAttribute("source", "#XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-normals-array");
                                    }
                                }

                            } else {
                                NodeList src_nor_tags = geo_tag.getElementsByTagName("source");

                                for (int m = 0; m < src_nor_tags.getLength(); m++) {
                                    Element src_nor_tag = (Element) src_nor_tags.item(m);

                                    if (src_nor_tag.getAttribute("id").compareToIgnoreCase("Cube-mesh-normals") == 0)
                                        src_nor_tag.getParentNode().removeChild(src_nor_tag);
                                }
                            }

                            Element mesh_tag = (Element) geo_tag.getElementsByTagName("mesh").item(0);
                            Element src_uv_temp = null;
                            NodeList src_uv_tags = geo_tag.getElementsByTagName("source");

                            for (int j = 0; j < src_uv_tags.getLength(); j++) {
                                Element src_uv_tag = (Element) src_uv_tags.item(j);

                                if (src_uv_tag.getAttribute("id").compareToIgnoreCase("Cube-mesh-map-0") == 0) {
                                    src_uv_temp = src_uv_tag;
                                    src_uv_tag.getParentNode().removeChild(src_uv_tag);
                                }
                            }
                            for (int i_uv = 0; i_uv < e_ch.mesh_chunk.uv_attrs.size(); i_uv++) {
                                Element src_uv_tag = (Element) Objects.requireNonNull(src_uv_temp).cloneNode(true);

                                mesh_tag.appendChild(src_uv_tag);

                                int num_uv = 0;

                                NodeList flo_poss = geo_tag.getElementsByTagName("float_array");

                                for (int m = 0; m < flo_poss.getLength(); m++) {
                                    Element flo_arr_tag = (Element) flo_poss.item(m);

                                    if (flo_arr_tag.getAttribute("id").compareToIgnoreCase("Cube-mesh-map-0-array") == 0) {
                                        flo_arr_tag.setAttribute("id", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-map-" + i_uv + "-array");

                                        StringBuilder str_buf = new StringBuilder();

                                        if (e_ch.mesh_chunk.uv_attrs.get(i_uv).uv_coords != null) {
                                            for (XACData.Chunk.MeshChunk.VerticesAttribute.UVCoord e_uv : e_ch.mesh_chunk.uv_attrs.get(i_uv).uv_coords) {
                                                str_buf.append(e_uv.u).append(" ").append(1.0F - e_uv.v).append(" ");
                                                num_uv++;
                                            }

                                            flo_arr_tag.setTextContent(str_buf.toString());
                                            flo_arr_tag.setAttribute("count", String.valueOf(e_ch.mesh_chunk.uv_attrs.get(i_uv).uv_coords.size() * 2));
                                        }
                                    }
                                }

                                src_uv_tag.setAttribute("id", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-map-" + i_uv);

                                NodeList accessor_poss = geo_tag.getElementsByTagName("accessor");

                                for (int n = 0; n < accessor_poss.getLength(); n++) {
                                    Element accessor_pos = (Element) accessor_poss.item(n);

                                    if (accessor_pos.getAttribute("source").compareToIgnoreCase("#Cube-mesh-map-0-array") == 0) {
                                        accessor_pos.setAttribute("count", String.valueOf(num_uv));
                                        accessor_pos.setAttribute("source", "#XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-map-" + i_uv + "-array");
                                    }
                                }
                            }

                            for (XACData.Chunk.MeshChunk.SubMesh e_subm : e_ch.mesh_chunk.sub_meshs) {
                                Element polylist_tag = (Element) poly_temp.cloneNode(true);

                                int face_num = e_subm.con_face_indices.length / 3;

                                polylist_tag.setAttribute("material", "XAC_Mat_" + e_subm.materialId + "-material");
                                polylist_tag.setAttribute("count", String.valueOf(face_num));

                                int num_attrs = 1;

                                if (e_ch.mesh_chunk.last_positions != null) {
                                    Element input_pos_tag = document.createElement("input");

                                    polylist_tag.appendChild(input_pos_tag);

                                    input_pos_tag.setAttribute("semantic", "VERTEX");
                                    input_pos_tag.setAttribute("source", "#XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-vertices");
                                    input_pos_tag.setAttribute("offset", "0");
                                }

                                if (e_ch.mesh_chunk.last_normals != null) {
                                    Element input_pos_tag = document.createElement("input");

                                    polylist_tag.appendChild(input_pos_tag);

                                    input_pos_tag.setAttribute("semantic", "NORMAL");
                                    input_pos_tag.setAttribute("source", "#XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-normals");
                                    input_pos_tag.setAttribute("offset", "1");

                                    num_attrs = 2;
                                }

                                for (int m = 0; m < e_ch.mesh_chunk.uv_attrs.size(); m++) {
                                    Element input_pos_tag = document.createElement("input");

                                    polylist_tag.appendChild(input_pos_tag);

                                    input_pos_tag.setAttribute("semantic", "TEXCOORD");
                                    input_pos_tag.setAttribute("source", "#XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-map-" + m);
                                    input_pos_tag.setAttribute("offset", "1");

                                    num_attrs = 2;
                                }

                                Element vcount_tag = (Element) polylist_tag.getElementsByTagName("vcount").item(0);

                                polylist_tag.removeChild(vcount_tag);
                                polylist_tag.appendChild(vcount_tag);

                                StringBuilder str_buf = new StringBuilder(face_num * 2);

                                str_buf.append("3 ".repeat(face_num));

                                vcount_tag.setTextContent(str_buf.toString());

                                Element p_tag = (Element) polylist_tag.getElementsByTagName("p").item(0);
                                polylist_tag.removeChild(p_tag);
                                polylist_tag.appendChild(p_tag);

                                str_buf = new StringBuilder(face_num * 6);

                                for (int i1 = 2; i1 < e_subm.con_face_indices.length; ) {
                                    int i2;

                                    for (i2 = 0; i2 < num_attrs; i2++) {
                                        if (i2 == 0)
                                            str_buf.append(e_subm.con_face_indices[i1]).append(" ");
                                        else
                                            str_buf.append(e_subm.relativeIndices[i1]).append(" ");
                                    }

                                    i1--;

                                    for (i2 = 0; i2 < num_attrs; i2++) {
                                        if (i2 == 0)
                                            str_buf.append(e_subm.con_face_indices[i1]).append(" ");
                                        else
                                            str_buf.append(e_subm.relativeIndices[i1]).append(" ");
                                    }

                                    i1--;

                                    for (i2 = 0; i2 < num_attrs; i2++) {
                                        if (i2 == 0)
                                            str_buf.append(e_subm.con_face_indices[i1]).append(" ");
                                        else
                                            str_buf.append(e_subm.relativeIndices[i1]).append(" ");
                                    }

                                    i1 += 5;
                                }

                                p_tag.setTextContent(str_buf.toString());
                                mesh_tag.appendChild(polylist_tag);
                            }

                            geo_tag.setAttribute("id", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh");

                            geo_tag.setAttribute("name", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId);

                            Element source_tag = (Element) geo_tag.getElementsByTagName("source").item(0);
                            source_tag.setAttribute("id", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-positions");

                            Element float_tag = (Element) geo_tag.getElementsByTagName("float_array").item(0);
                            float_tag.setAttribute("id", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-positions-array");

                            Element accessor_tag = (Element) geo_tag.getElementsByTagName("accessor").item(0);
                            accessor_tag.setAttribute("source", "#XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-positions-array");

                            Element vert_tag = (Element) geo_tag.getElementsByTagName("vertices").item(0);
                            vert_tag.setAttribute("id", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-vertices");

                            NodeList input_tags = geo_tag.getElementsByTagName("input");

                            for (int k = 0; k < input_tags.getLength(); k++) {
                                Element input_tag = (Element) input_tags.item(k);

                                if (input_tag.getAttribute("semantic").compareToIgnoreCase("POSITION") == 0)
                                    input_tag.setAttribute("source", "#XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh-positions");
                            }

                            Element node_mesh = (Element) node_mesh_temp.cloneNode(true);

                            if (e_ch.mesh_chunk.relativeSkin == null) {
                                Element insta_con = (Element) node_mesh.getElementsByTagName("instance_controller").item(0);

                                insta_con.getParentNode().removeChild(insta_con);

                                Element insta_geo = (Element) node_mesh.getElementsByTagName("instance_geometry").item(0);

                                insta_geo.setAttribute("url", "#XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh");
                                insta_geo.setAttribute("name", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId);

                            } else {
                                Element insta_geo = (Element) node_mesh.getElementsByTagName("instance_geometry").item(0);

                                insta_geo.getParentNode().removeChild(insta_geo);

                                Element insta_con = (Element) node_mesh.getElementsByTagName("instance_controller").item(0);

                                insta_con.setAttribute("url", "#Armature_XAC_" + e_ch.mesh_chunk.nodeId + "-skin");

                                Element skel_tag_temp = (Element) insta_con.getElementsByTagName("skeleton").item(0);
                                Element node_armature_tag = (Element) node_armature_temp.cloneNode(true);

                                visual_scene_tag.appendChild(node_armature_tag);

                                ArrayList<Short> ref_vgroup_list = e_ch.mesh_chunk.relativeSkin.boneIdList;
                                XACData.Chunk.SkinChunk ref_skin = e_ch.mesh_chunk.relativeSkin;

                                Matrix4d mat_var = new Matrix4d();
                                Vector3d vec_var = new Vector3d();

                                int node_i = 0;

                                XACData.Chunk.NodeChunk.NodeData[] arrayOfNodeData;

                                for (int m = 0; m < (arrayOfNodeData = xac.nodes.node_datas).length; m++) {
                                    XACData.Chunk.NodeChunk.NodeData e_node_data = arrayOfNodeData[m];

                                    Element skelton_tag = (Element) skel_tag_temp.cloneNode(true);

                                    insta_con.appendChild(skelton_tag);

                                    skelton_tag.setTextContent("#B_" + node_i + "_" + e_node_data.name_str_removed);

                                    Element node_bone_tag = (Element) node_bone_temp.cloneNode(true);

                                    node_armature_tag.appendChild(node_bone_tag);

                                    node_bone_tag.setAttribute("id", "B_" + node_i + "_" + e_node_data.name_str_removed);
                                    node_bone_tag.setAttribute("name", "B_" + node_i + "_" + e_node_data.name_str_removed);
                                    node_bone_tag.setAttribute("sid", "B_" + node_i + "_" + e_node_data.name_str_removed);

                                    mat_var.setIdentity();
                                    vec_var.set(e_node_data.position);
                                    vec_var.z = -vec_var.z;
                                    mat_var.setTranslation(vec_var);

                                    Element matrix_tag = (Element) node_bone_tag.getElementsByTagName("matrix").item(0);

                                    matrix_tag.setTextContent(e_node_data.transform.m00 + " " + e_node_data.transform.m01 + " " + e_node_data.transform.m02 + " " +
                                            e_node_data.transform.m03 + " " + e_node_data.transform.m10 + " " + e_node_data.transform.m11 + " " +
                                            e_node_data.transform.m12 + " " + e_node_data.transform.m13 + " " + e_node_data.transform.m20 + " " +
                                            e_node_data.transform.m21 + " " + e_node_data.transform.m22 + " " + e_node_data.transform.m23 + " " +
                                            e_node_data.transform.m30 + " " + e_node_data.transform.m31 + " " + e_node_data.transform.m32 + " " +
                                            e_node_data.transform.m33);

                                    node_i++;
                                }

                                Element controller_tag = (Element) controller_temp.cloneNode(true);

                                lib_con_tag.appendChild(controller_tag);

                                controller_tag.setAttribute("id", "Armature_XAC_" + e_ch.mesh_chunk.nodeId + "-skin");

                                Element skin_tag = (Element) controller_tag.getElementsByTagName("skin").item(0);

                                skin_tag.setAttribute("source", "#XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-mesh");

                                NodeList source_tags = skin_tag.getElementsByTagName("source");

                                for (int n = 0; n < source_tags.getLength(); n++) {
                                    Element src_tag = (Element) source_tags.item(n);

                                    if (src_tag.getAttribute("id").compareToIgnoreCase("Armature_Cube-skin-joints") == 0) {
                                        Element name_array_tag = (Element) src_tag.getElementsByTagName("Name_array").item(0);

                                        name_array_tag.setAttribute("id", "Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-joints-array");
                                        name_array_tag.setAttribute("count", String.valueOf(ref_vgroup_list.size()));

                                        StringBuilder bone_names = new StringBuilder(6 * ref_vgroup_list.size());

                                        for (Short e_bone_id : ref_vgroup_list)
                                            bone_names.append("B_").append(e_bone_id).append("_").append((xac.nodes.node_datas[e_bone_id]).name_str_removed).append(" ");

                                        name_array_tag.setTextContent(bone_names.toString());

                                        Element acces_tag = (Element) src_tag.getElementsByTagName("accessor").item(0);

                                        acces_tag.setAttribute("source", "#Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-joints-array");
                                        acces_tag.setAttribute("count", String.valueOf(ref_vgroup_list.size()));
                                        src_tag.setAttribute("id", "Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-joints");
                                    }

                                    if (src_tag.getAttribute("id").compareToIgnoreCase("Armature_Cube-skin-bind_poses") == 0) {
                                        Element float_array_tag = (Element) src_tag.getElementsByTagName("float_array").item(0);

                                        float_array_tag.setAttribute("count", String.valueOf(16 * ref_vgroup_list.size()));
                                        float_array_tag.setAttribute("id", "Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-bind_poses-array");

                                        String val = float_array_tag.getTextContent().trim();

                                        StringBuilder str_buf = new StringBuilder(val.length() * ref_vgroup_list.size());

                                        for (XACData.Chunk.NodeChunk.NodeData e_node : xac.nodes.node_datas) {
                                            mat_var.setIdentity();
                                            vec_var.set(e_node.position);
                                            vec_var.z = -vec_var.z;
                                            mat_var.setTranslation(vec_var);

                                            str_buf.append(e_node.transform.m00).append(" ").append(e_node.transform.m01).append(" ").append(e_node.transform.m02).append(" ").append(e_node.transform.m03).append(" ").append(e_node.transform.m10).append(" ").append(e_node.transform.m11).append(" ").append(e_node.transform.m12).append(" ").append(e_node.transform.m13).append(" ").append(e_node.transform.m20).append(" ").append(e_node.transform.m21).append(" ").append(e_node.transform.m22).append(" ").append(e_node.transform.m23).append(" ").append(e_node.transform.m30).append(" ").append(e_node.transform.m31).append(" ").append(e_node.transform.m32).append(" ").append(e_node.transform.m33).append(" ");
                                        }

                                        float_array_tag.setTextContent(str_buf.toString());

                                        Element access_tag = (Element) src_tag.getElementsByTagName("accessor").item(0);

                                        access_tag.setAttribute("source", "#Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-bind_poses-array");
                                        access_tag.setAttribute("count", String.valueOf(ref_vgroup_list.size()));
                                        src_tag.setAttribute("id", "Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-bind_poses");
                                    }

                                    if (src_tag.getAttribute("id").compareToIgnoreCase("Armature_Cube-skin-weights") == 0) {
                                        Element float_array_tag = (Element) src_tag.getElementsByTagName("float_array").item(0);

                                        float_array_tag.setAttribute("id", "Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-weights-array");
                                        float_array_tag.setAttribute("count", String.valueOf(ref_skin.influ_datas.length));

                                        StringBuilder wei_str = new StringBuilder(ref_skin.influ_datas.length * 2);

                                        for (int ind = 0; ind < ref_skin.influ_datas.length; ind++)
                                            wei_str.append((ref_skin.influ_datas[ind]).fWeight).append(" ");

                                        float_array_tag.setTextContent(wei_str.toString());

                                        Element acces_tag = (Element) src_tag.getElementsByTagName("accessor").item(0);

                                        acces_tag.setAttribute("source", "#Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-weights-array");
                                        acces_tag.setAttribute("count", String.valueOf(ref_skin.influ_datas.length));
                                        src_tag.setAttribute("id", "Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-weights");
                                    }

                                    Element joints_tag = (Element) controller_tag.getElementsByTagName("joints").item(0);
                                    NodeList inputs = joints_tag.getElementsByTagName("input");

                                    for (int cc = 0; cc < inputs.getLength(); cc++) {
                                        Element input_tag = (Element) inputs.item(cc);
                                        if (input_tag.getAttribute("semantic").compareToIgnoreCase("JOINT") == 0)
                                            input_tag.setAttribute("source", "#Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-joints");
                                        if (input_tag.getAttribute("semantic").compareToIgnoreCase("INV_BIND_MATRIX") == 0)
                                            input_tag.setAttribute("source", "#Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-bind_poses");
                                    }

                                    Element vertex_weights_tag = (Element) controller_tag.getElementsByTagName("vertex_weights").item(0);
                                    vertex_weights_tag.setAttribute("count", String.valueOf(e_ch.mesh_chunk.last_positions.new_positions.size()));
                                    NodeList vw_inputs = vertex_weights_tag.getElementsByTagName("input");

                                    for (int i1 = 0; i1 < inputs.getLength(); i1++) {
                                        Element input_tag = (Element) vw_inputs.item(i1);

                                        if (input_tag.getAttribute("semantic").compareToIgnoreCase("JOINT") == 0)
                                            input_tag.setAttribute("source", "#Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-joints");

                                        if (input_tag.getAttribute("semantic").compareToIgnoreCase("WEIGHT") == 0)
                                            input_tag.setAttribute("source", "#Armature_XAC_Mesh_" + e_ch.mesh_chunk.nodeId + "-skin-weights");
                                    }

                                    Element vcount_tag = (Element) vertex_weights_tag.getElementsByTagName("vcount").item(0);
                                    StringBuilder vcount_str = new StringBuilder(e_ch.mesh_chunk.last_positions.new_positions.size() * 2);

                                    for (XACData.Chunk.MeshChunk.VerticesAttribute.NewPosition e_np : e_ch.mesh_chunk.last_positions.new_positions)
                                        vcount_str.append((ref_skin.influ_ranges[e_np.index_of_range]).numInfluences).append(" ");

                                    vcount_tag.setTextContent(vcount_str.toString());

                                    Element v_tag = (Element) vertex_weights_tag.getElementsByTagName("v").item(0);
                                    StringBuilder v_str = new StringBuilder(ref_skin.influ_datas.length);

                                    for (XACData.Chunk.MeshChunk.VerticesAttribute.NewPosition e_np : e_ch.mesh_chunk.last_positions.new_positions) {
                                        int first = (ref_skin.influ_ranges[e_np.index_of_range]).firstInfluenceIndex;
                                        int last = (ref_skin.influ_ranges[e_np.index_of_range]).firstInfluenceIndex +
                                                (ref_skin.influ_ranges[e_np.index_of_range]).numInfluences;
                                        for (int index = first; index < last; index++)
                                            v_str.append(ref_skin.boneIdList.indexOf((ref_skin.influ_datas[index]).boneId)).append(" ").append(index).append(" ");
                                    }

                                    v_tag.setTextContent(v_str.toString());
                                    vcount_tag.setTextContent(vcount_str.toString());
                                }

                                node_armature_tag.setAttribute("id", "Armature_XAC_" + e_ch.mesh_chunk.nodeId);
                                node_armature_tag.setAttribute("name", "Armature_XAC_" + e_ch.mesh_chunk.nodeId);

                                skel_tag_temp.getParentNode().removeChild(skel_tag_temp);
                            }

                            node_mesh.setAttribute("id", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId);
                            node_mesh.setAttribute("name", "XAC_Mesh_" + e_ch.mesh_chunk.nodeId);

                            visual_scene_tag.appendChild(node_mesh);

                            lib_geo.appendChild(geo_tag);
                        }
                    }

                    TransformerFactory transformerFactory = TransformerFactory.newInstance();

                    Transformer transformer = transformerFactory.newTransformer();

                    transformer.setOutputProperty("indent", "yes");
                    transformer.setOutputProperty("method", "xml");
                    transformer.setOutputProperty("encoding", "UTF-8");

                    transformer.transform(new DOMSource(document), new StreamResult(new File(xac_file.getAbsolutePath() + ".dae")));

                    input.close();

                } catch (IOException | ParserConfigurationException | SAXException | TransformerException exception) {
                    exception.printStackTrace();
                }
            }
        }
    }

    private static void removeSpace(Element root) {
        NodeList children = root.getChildNodes();

        for (int i = 0; i < children.getLength(); i++) {
            if (children.item(i) instanceof Element element)
                removeSpace(element);
            else if (children.item(i) instanceof Text text)
                text.setTextContent(text.getTextContent().trim());
        }
    }
}