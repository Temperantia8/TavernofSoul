package xac.daeconverter;

import javax.vecmath.Matrix4f;
import javax.vecmath.Vector3d;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

class XACData {

    byte[] file_id = new byte[4];

    byte[] major_ver = new byte[1];

    byte[] minor_ver = new byte[1];

    byte[] bBigEndian = new byte[1];

    byte[] multiplyOrder = new byte[1];

    ArrayList<Chunk> chunks = new ArrayList<>();

    Chunk.NodeChunk nodes;

    XACData(BufferedInputStream bis) {
        try {
            bis.read(this.file_id);

            if (this.file_id[0] != 88 && this.file_id[1] != 65 && this.file_id[2] != 67 && this.file_id[3] != 32)
                throw new Error("This is not an XAC file");

            bis.read(this.major_ver);
            bis.read(this.minor_ver);
            bis.read(this.bBigEndian);
            bis.read(this.multiplyOrder);

            while (bis.available() > 0)
                this.chunks.add(new Chunk(bis));

            convertDAE();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void convertDAE() {
        for (Chunk e_mesh_ch : this.chunks) {
            if (e_mesh_ch.chunk_type == 1) {
                Chunk.MeshChunk.VerticesAttribute e_pos = e_mesh_ch.mesh_chunk.last_positions;

                e_pos.full_con_pos = new Chunk.MeshChunk.VerticesAttribute.NewPosition[e_mesh_ch.mesh_chunk.last_positions.positions.size()];

                for (int i = 0; i < e_pos.full_con_pos.length; i++) {
                    e_pos.getClass();
                    e_pos.full_con_pos[i] = e_pos.new NewPosition();
                    (e_pos.full_con_pos[i]).x = e_mesh_ch.mesh_chunk.last_positions.positions.get(i).x;
                    (e_pos.full_con_pos[i]).y = e_mesh_ch.mesh_chunk.last_positions.positions.get(i).y;
                    (e_pos.full_con_pos[i]).z = e_mesh_ch.mesh_chunk.last_positions.positions.get(i).z;

                    if (e_mesh_ch.mesh_chunk.last_normals != null)
                        (e_pos.full_con_pos[i]).ref_normal = e_mesh_ch.mesh_chunk.last_normals.normals[i];

                    if (e_mesh_ch.mesh_chunk.relativeSkin != null) {
                        int num_of_inf = (e_mesh_ch.mesh_chunk.relativeSkin.influ_ranges[(e_mesh_ch.mesh_chunk.last_influranges.influ_range_indexs[i]).influRangeIngex]).numInfluences;
                        int start_inf = (e_mesh_ch.mesh_chunk.relativeSkin.influ_ranges[(e_mesh_ch.mesh_chunk.last_influranges.influ_range_indexs[i]).influRangeIngex]).firstInfluenceIndex;
                        (e_pos.full_con_pos[i]).index_of_range = (e_mesh_ch.mesh_chunk.last_influranges.influ_range_indexs[i]).influRangeIngex;
                        (e_pos.full_con_pos[i]).weights = new Chunk.SkinChunk.InfluenceData[num_of_inf];
                        System.arraycopy(e_mesh_ch.mesh_chunk.relativeSkin.influ_datas, start_inf, (e_pos.full_con_pos[i]).weights, 0, (e_pos.full_con_pos[i]).weights.length);
                    }
                }

                Chunk.MeshChunk.VerticesAttribute.NewPosition[] arrayOfNewPosition;

                for (int j = 0; j < (arrayOfNewPosition = e_pos.full_con_pos).length; j++) {
                    Chunk.MeshChunk.VerticesAttribute.NewPosition e_fulp = arrayOfNewPosition[j];

                    int same_i = 0;

                    Chunk.MeshChunk.VerticesAttribute.NewPosition[] arrayOfNewPosition1;

                    for (int k = 0; k < (arrayOfNewPosition1 = e_pos.full_con_pos).length; k++) {
                        Chunk.MeshChunk.VerticesAttribute.NewPosition on_fulp = arrayOfNewPosition1[k];
                        if (e_fulp.ref_normal != null && e_fulp.weights != null && e_fulp.x == on_fulp.x && e_fulp.y == on_fulp.y && e_fulp.z == on_fulp.z && e_fulp.ref_normal.n_x == on_fulp.ref_normal.n_x && e_fulp.ref_normal.n_y == on_fulp.ref_normal.n_y && e_fulp.ref_normal.n_z == on_fulp.ref_normal.n_z) {
                            int same_num = 0;

                            Chunk.SkinChunk.InfluenceData[] arrayOfInfluenceData;

                            for (int m = 0; m < (arrayOfInfluenceData = e_fulp.weights).length; m++) {
                                Chunk.SkinChunk.InfluenceData en_inf = arrayOfInfluenceData[m];

                                Chunk.SkinChunk.InfluenceData[] arrayOfInfluenceData1;

                                for (int n = 0; n < (arrayOfInfluenceData1 = on_fulp.weights).length; n++) {
                                    Chunk.SkinChunk.InfluenceData on_inf = arrayOfInfluenceData1[n];

                                    if (en_inf.boneId == on_inf.boneId && en_inf.fWeight == on_inf.fWeight)
                                        same_num++;
                                }
                            }

                            if (same_num == e_fulp.weights.length) {
                                if (e_fulp == on_fulp) {
                                    e_pos.new_positions.add(e_fulp);
                                    e_fulp.new_con_index = e_pos.new_positions.size() - 1;
                                    break;
                                }

                                e_fulp.new_con_index = on_fulp.new_con_index;
                                break;
                            }
                        }

                        if (e_fulp.ref_normal == null && e_fulp.weights != null && e_fulp.x == on_fulp.x && e_fulp.y == on_fulp.y && e_fulp.z == on_fulp.z) {
                            int same_num = 0;

                            Chunk.SkinChunk.InfluenceData[] arrayOfInfluenceData;

                            for (int m = 0; m < (arrayOfInfluenceData = e_fulp.weights).length; m++) {
                                Chunk.SkinChunk.InfluenceData en_inf = arrayOfInfluenceData[m];

                                Chunk.SkinChunk.InfluenceData[] arrayOfInfluenceData1;

                                for (int n = 0; n < (arrayOfInfluenceData1 = on_fulp.weights).length; n++) {
                                    Chunk.SkinChunk.InfluenceData on_inf = arrayOfInfluenceData1[n];

                                    if (en_inf.boneId == on_inf.boneId && en_inf.fWeight == on_inf.fWeight)
                                        same_num++;
                                }
                            }

                            if (same_num == e_fulp.weights.length) {
                                if (e_fulp == on_fulp) {
                                    e_pos.new_positions.add(e_fulp);
                                    e_fulp.new_con_index = e_pos.new_positions.size() - 1;
                                    break;
                                }

                                e_fulp.new_con_index = on_fulp.new_con_index;
                                break;
                            }
                        }

                        if (e_fulp.ref_normal == null && e_fulp.weights == null && e_fulp.x == on_fulp.x && e_fulp.y == on_fulp.y && e_fulp.z == on_fulp.z) {
                            if (e_fulp == on_fulp) {
                                e_pos.new_positions.add(e_fulp);
                                e_fulp.new_con_index = e_pos.new_positions.size() - 1;
                                break;
                            }

                            e_fulp.new_con_index = on_fulp.new_con_index;
                            break;
                        }

                        if (e_fulp.ref_normal != null && e_fulp.weights == null && e_fulp.x == on_fulp.x && e_fulp.y == on_fulp.y && e_fulp.z == on_fulp.z && e_fulp.ref_normal.n_x == on_fulp.ref_normal.n_x && e_fulp.ref_normal.n_y == on_fulp.ref_normal.n_y && e_fulp.ref_normal.n_z == on_fulp.ref_normal.n_z) {
                            if (e_fulp == on_fulp) {
                                e_pos.new_positions.add(e_fulp);
                                e_fulp.new_con_index = e_pos.new_positions.size() - 1;
                                break;
                            }

                            e_fulp.new_con_index = on_fulp.new_con_index;
                            break;
                        }

                        same_i++;
                    }
                }

                for (Chunk.MeshChunk.SubMesh e_sub : e_mesh_ch.mesh_chunk.sub_meshs) {
                    e_sub.con_face_indices = new int[e_sub.relativeIndices.length];

                    for (int i_con = 0; i_con < e_sub.relativeIndices.length; i_con++)
                        e_sub.con_face_indices[i_con] = (e_pos.full_con_pos[e_sub.relativeIndices[i_con]]).new_con_index;
                }
            }
        }
    }

    class Chunk {

        int chunk_type;

        int length;

        int version;

        byte[] data;

        MeshChunk mesh_chunk;

        SkinChunk skin_chunk;

        NodeChunk node_chunk;

        Chunk(BufferedInputStream bis) {
            try {
                byte[] dword = new byte[4];

                ByteBuffer dword_buf = ByteBuffer.wrap(dword);

                dword_buf.order(ByteOrder.LITTLE_ENDIAN);

                bis.read(dword);

                this.chunk_type = dword_buf.getInt();

                dword_buf.clear();

                System.out.println("Chunk Type is " + this.chunk_type);

                bis.read(dword);

                this.length = dword_buf.getInt();

                dword_buf.clear();

                bis.read(dword);

                this.version = dword_buf.getInt();

                dword_buf.clear();

                switch (this.chunk_type) {
                    case 1 -> this.mesh_chunk = new MeshChunk(bis);
                    case 2 -> this.skin_chunk = new SkinChunk(bis);
                    case 11 -> this.node_chunk = new NodeChunk(bis);

                    default -> {
                        this.data = new byte[this.length];
                        bis.read(this.data);
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        class MeshChunk {

            int nodeId;

            int numInfluenceRanges;

            int numTotalVertices;

            int numTotalIndices;

            int numSubMeshes;

            int numAttribLayers;

            byte[] bIsCollisionMesh = new byte[1];

            byte[] pad = new byte[3];

            int rest_mesh;

            byte[] rest_data;

            ArrayList<VerticesAttribute> attrs = new ArrayList<>();

            ArrayList<SubMesh> sub_meshs = new ArrayList<>();

            SkinChunk relativeSkin;

            VerticesAttribute last_influranges;

            VerticesAttribute last_positions;

            VerticesAttribute last_normals;

            ArrayList<VerticesAttribute> uv_attrs = new ArrayList<>();

            MeshChunk(BufferedInputStream bis) {
                try {
                    this.rest_mesh = Chunk.this.length;

                    byte[] dword = new byte[4];

                    ByteBuffer dword_buf = ByteBuffer.wrap(dword);

                    dword_buf.order(ByteOrder.LITTLE_ENDIAN);

                    bis.read(dword);
                    this.nodeId = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_mesh -= 4;

                    bis.read(dword);
                    this.numInfluenceRanges = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_mesh -= 4;

                    bis.read(dword);
                    this.numTotalVertices = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_mesh -= 4;

                    bis.read(dword);
                    this.numTotalIndices = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_mesh -= 4;

                    bis.read(dword);
                    this.numSubMeshes = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_mesh -= 4;

                    bis.read(dword);
                    this.numAttribLayers = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_mesh -= 4;

                    bis.read(this.bIsCollisionMesh);

                    this.rest_mesh--;

                    bis.read(this.pad);

                    this.rest_mesh -= 3;

                    for (int i = 0; i < this.numAttribLayers; i++)
                        this.attrs.add(new VerticesAttribute(bis));

                    for (int i = 0; i < this.numSubMeshes; i++)
                        this.sub_meshs.add(new SubMesh(bis));

                    if (this.rest_mesh < 0)
                        System.out.println("Remaining " + this.rest_mesh);

                    this.rest_data = new byte[this.rest_mesh];

                    bis.read(this.rest_data);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            class VerticesAttribute {

                int type_attr;

                int attribSize;

                byte[] bKeepOriginals = new byte[1];

                byte[] bIsScaleFactor = new byte[1];

                byte[] pad_attr = new byte[2];

                byte[] data_attr;

                ArrayList<Position> positions = new ArrayList<>();

                ArrayList<UVCoord> uv_coords = new ArrayList<>();

                InfluRangeIndex[] influ_range_indexs;

                Normal[] normals;

                NewPosition[] full_con_pos;

                ArrayList<NewPosition> new_positions = new ArrayList<>();

                VerticesAttribute(BufferedInputStream bis) {
                    try {
                        byte[] dword = new byte[4];

                        ByteBuffer dword_buf = ByteBuffer.wrap(dword);

                        dword_buf.order(ByteOrder.LITTLE_ENDIAN);

                        bis.read(dword);
                        this.type_attr = dword_buf.getInt();

                        System.out.println("Attribute Type is" + this.type_attr);

                        dword_buf.clear();

                        MeshChunk.this.rest_mesh -= 4;

                        bis.read(dword);
                        this.attribSize = dword_buf.getInt();

                        dword_buf.clear();

                        MeshChunk.this.rest_mesh -= 4;

                        bis.read(this.bKeepOriginals);

                        MeshChunk.this.rest_mesh--;

                        bis.read(this.bIsScaleFactor);

                        MeshChunk.this.rest_mesh--;

                        bis.read(this.pad_attr);

                        MeshChunk.this.rest_mesh -= 2;

                        if (this.type_attr == 0 && this.attribSize == 12)
                            for (int i = 0; i < MeshChunk.this.numTotalVertices; i++) {
                                MeshChunk.this.last_positions = this;

                                Position pos = new Position();

                                bis.read(dword);
                                pos.x = dword_buf.getFloat();

                                dword_buf.clear();

                                MeshChunk.this.rest_mesh -= 4;

                                bis.read(dword);
                                pos.y = dword_buf.getFloat();

                                dword_buf.clear();

                                MeshChunk.this.rest_mesh -= 4;

                                bis.read(dword);
                                pos.z = dword_buf.getFloat();

                                dword_buf.clear();

                                MeshChunk.this.rest_mesh -= 4;

                                this.positions.add(pos);
                            }

                        if (this.type_attr == 3 && this.attribSize == 8) {
                            MeshChunk.this.uv_attrs.add(this);

                            for (int i = 0; i < MeshChunk.this.numTotalVertices; i++) {
                                UVCoord uv = new UVCoord();

                                bis.read(dword);
                                uv.u = dword_buf.getFloat();

                                dword_buf.clear();

                                MeshChunk.this.rest_mesh -= 4;

                                bis.read(dword);
                                uv.v = dword_buf.getFloat();

                                dword_buf.clear();

                                MeshChunk.this.rest_mesh -= 4;

                                this.uv_coords.add(uv);
                            }
                        }

                        if (this.type_attr == 5 && this.attribSize == 4) {
                            this.influ_range_indexs = new InfluRangeIndex[MeshChunk.this.numTotalVertices];

                            MeshChunk.this.last_influranges = this;

                            for (int i = 0; i < MeshChunk.this.numTotalVertices; i++) {
                                this.influ_range_indexs[i] = new InfluRangeIndex();

                                bis.read(dword);

                                this.influ_range_indexs[i].influRangeIngex = dword_buf.getInt();

                                dword_buf.clear();

                                MeshChunk.this.rest_mesh -= 4;
                            }
                        }

                        if (this.type_attr == 1 && this.attribSize == 12) {
                            MeshChunk.this.last_normals = this;

                            this.normals = new Normal[MeshChunk.this.numTotalVertices];

                            for (int i = 0; i < MeshChunk.this.numTotalVertices; i++) {
                                this.normals[i] = new Normal();

                                bis.read(dword);

                                (this.normals[i]).n_x = dword_buf.getFloat();

                                dword_buf.clear();

                                MeshChunk.this.rest_mesh -= 4;

                                bis.read(dword);

                                (this.normals[i]).n_y = dword_buf.getFloat();

                                dword_buf.clear();

                                MeshChunk.this.rest_mesh -= 4;

                                bis.read(dword);

                                (this.normals[i]).n_z = dword_buf.getFloat();

                                dword_buf.clear();

                                MeshChunk.this.rest_mesh -= 4;
                            }
                        }

                        if (this.type_attr != 0 && this.type_attr != 3 && this.type_attr != 5 && this.type_attr != 1) {
                            this.data_attr = new byte[MeshChunk.this.numTotalVertices * this.attribSize];

                            bis.read(this.data_attr);

                            MeshChunk.this.rest_mesh -= MeshChunk.this.numTotalVertices * this.attribSize;
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                class Position {

                    float x, y, z;
                }

                class NewPosition {

                    float x, y, z;

                    XACData.Chunk.SkinChunk.InfluenceData[] weights;

                    int index_of_range = -1;

                    XACData.Chunk.MeshChunk.VerticesAttribute.Normal ref_normal;

                    int new_con_index = -1;
                }

                class UVCoord {

                    float u, v;
                }

                class InfluRangeIndex {

                    int influRangeIngex;
                }

                class Normal {

                    float n_x, n_y, n_z;
                }
            }

            class SubMesh {

                int numSubIndices;

                int numSubVertices;

                int materialId;

                int numBones;

                int[] relativeIndices;

                int[] con_face_indices;

                int[] boneIds;

                SubMesh(BufferedInputStream bis) {
                    try {
                        byte[] dword = new byte[4];

                        ByteBuffer dword_buf = ByteBuffer.wrap(dword);

                        dword_buf.order(ByteOrder.LITTLE_ENDIAN);

                        byte[] dshort = new byte[2];

                        ByteBuffer dshort_buf = ByteBuffer.wrap(dshort);

                        dshort_buf.order(ByteOrder.LITTLE_ENDIAN);

                        bis.read(dword);
                        this.numSubIndices = dword_buf.getInt();

                        dword_buf.clear();

                        MeshChunk.this.rest_mesh -= 4;

                        bis.read(dword);
                        this.numSubVertices = dword_buf.getInt();

                        dword_buf.clear();

                        MeshChunk.this.rest_mesh -= 4;

                        bis.read(dword);
                        this.materialId = dword_buf.getInt();

                        dword_buf.clear();

                        MeshChunk.this.rest_mesh -= 4;

                        bis.read(dword);
                        this.numBones = dword_buf.getInt();

                        dword_buf.clear();

                        MeshChunk.this.rest_mesh -= 4;

                        this.relativeIndices = new int[this.numSubIndices];

                        for (int i = 0; i < this.numSubIndices; i++) {
                            bis.read(dword);
                            this.relativeIndices[i] = dword_buf.getInt();

                            dword_buf.clear();

                            MeshChunk.this.rest_mesh -= 4;
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        class SkinChunk {

            int nodeId;

            int numLocalBones;

            int numInfluences;

            byte[] bIsForCollisionMesh = new byte[1];

            byte[] pad = new byte[3];

            int rest_skin;

            byte[] rest_mesh_data;

            InfluenceData[] influ_datas;

            XACData.Chunk.MeshChunk relativeMesh;

            InfluenceRange[] influ_ranges;

            ArrayList<Short> boneIdList = new ArrayList<>();

            SkinChunk(BufferedInputStream bis) {
                try {
                    this.rest_skin = Chunk.this.length;

                    byte[] dword = new byte[4];

                    ByteBuffer dword_buf = ByteBuffer.wrap(dword);

                    dword_buf.order(ByteOrder.LITTLE_ENDIAN);

                    byte[] dshort = new byte[2];

                    ByteBuffer dshort_buf = ByteBuffer.wrap(dshort);

                    dshort_buf.order(ByteOrder.LITTLE_ENDIAN);

                    bis.read(dword);
                    this.nodeId = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_skin -= 4;

                    bis.read(dword);
                    this.numLocalBones = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_skin -= 4;

                    bis.read(dword);
                    this.numInfluences = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_skin -= 4;

                    bis.read(this.bIsForCollisionMesh);

                    this.rest_skin--;

                    bis.read(this.pad);

                    this.rest_skin -= 3;

                    this.influ_datas = new InfluenceData[this.numInfluences];

                    for (int i = 0; i < this.influ_datas.length; i++) {
                        this.influ_datas[i] = new InfluenceData();

                        bis.read(dword);
                        (this.influ_datas[i]).fWeight = dword_buf.getFloat();

                        dword_buf.clear();

                        this.rest_skin -= 4;

                        bis.read(dshort);
                        (this.influ_datas[i]).boneId = dshort_buf.getShort();

                        dshort_buf.clear();

                        this.rest_skin -= 2;

                        bis.read((this.influ_datas[i]).pad);

                        this.rest_skin -= 2;

                        boolean idExist = false;

                        for (Short e_id : this.boneIdList) {
                            if (e_id == (this.influ_datas[i]).boneId) {
                                idExist = true;
                                break;
                            }
                        }

                        if (!idExist)
                            this.boneIdList.add((this.influ_datas[i]).boneId);
                    }

                    for (XACData.Chunk e_mesh_ch : XACData.this.chunks) {
                        if (e_mesh_ch.chunk_type == 1 && e_mesh_ch.mesh_chunk.nodeId == this.nodeId) {
                            this.relativeMesh = e_mesh_ch.mesh_chunk;
                            e_mesh_ch.mesh_chunk.relativeSkin = this;
                        }
                    }

                    this.influ_ranges = new InfluenceRange[this.relativeMesh.numInfluenceRanges];

                    for (int i = 0; i < this.influ_ranges.length; i++) {
                        this.influ_ranges[i] = new InfluenceRange();

                        bis.read(dword);
                        (this.influ_ranges[i]).firstInfluenceIndex = dword_buf.getInt();

                        dword_buf.clear();

                        this.rest_skin -= 4;

                        bis.read(dword);
                        (this.influ_ranges[i]).numInfluences = dword_buf.getInt();

                        dword_buf.clear();

                        this.rest_skin -= 4;
                    }

                    if (this.rest_skin < 0)
                        System.out.println("Remaining " + this.rest_skin);

                    this.rest_mesh_data = new byte[this.rest_skin];

                    bis.read(this.rest_mesh_data);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            class InfluenceData {

                float fWeight;

                short boneId;

                byte[] pad = new byte[2];
            }

            class InfluenceRange {

                int firstInfluenceIndex;

                int numInfluences;
            }
        }

        class NodeChunk {

            int rest_nodec;

            int numNodes;

            int numRootNodes;

            NodeData[] node_datas;

            NodeChunk(BufferedInputStream bis) {
                XACData.this.nodes = this;
                try {
                    this.rest_nodec = Chunk.this.length;

                    byte[] dword = new byte[4];

                    ByteBuffer dword_buf = ByteBuffer.wrap(dword);

                    dword_buf.order(ByteOrder.LITTLE_ENDIAN);

                    byte[] dshort = new byte[2];

                    ByteBuffer dshort_buf = ByteBuffer.wrap(dshort);

                    dshort_buf.order(ByteOrder.LITTLE_ENDIAN);

                    bis.read(dword);
                    this.numNodes = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_nodec -= 4;
                    bis.read(dword);
                    this.numRootNodes = dword_buf.getInt();

                    dword_buf.clear();

                    this.rest_nodec -= 4;

                    this.node_datas = new NodeData[this.numNodes];

                    for (int i = 0; i < this.numNodes; i++) {
                        this.node_datas[i] = new NodeData(bis);
                        String str = new String((this.node_datas[i]).name, StandardCharsets.UTF_8);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            class NodeData {

                byte[] rotation = new byte[4];

                byte[] scaleRotation = new byte[4];

                Vector3d position = new Vector3d();

                Vector3d scale = new Vector3d();

                float[] unused = new float[3];

                int ques0;

                int ques1;

                int parentNodeId;

                int numChildNodes;

                int bIncludeInBoundsCalc;

                Matrix4f transform = new Matrix4f();

                float fImportanceFactor;

                int numString;

                byte[] name;

                String name_str;

                String name_str_removed;

                NodeData(BufferedInputStream bis) {
                    try {
                        byte[] dword = new byte[4];

                        ByteBuffer dword_buf = ByteBuffer.wrap(dword);

                        dword_buf.order(ByteOrder.LITTLE_ENDIAN);

                        byte[] dshort = new byte[2];

                        ByteBuffer dshort_buf = ByteBuffer.wrap(dshort);

                        dshort_buf.order(ByteOrder.LITTLE_ENDIAN);

                        byte[] doub = new byte[8];

                        ByteBuffer doub_buf = ByteBuffer.wrap(doub);

                        doub_buf.order(ByteOrder.LITTLE_ENDIAN);
                        bis.read(this.rotation);

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(this.scaleRotation);

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(doub);
                        this.position.x = doub_buf.getDouble();

                        doub_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 8;
                        bis.read(doub);
                        this.position.y = doub_buf.getDouble();

                        doub_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 8;
                        bis.read(doub);
                        this.position.z = doub_buf.getDouble();

                        doub_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 8;
                        bis.read(doub);
                        this.scale.x = doub_buf.getDouble();

                        doub_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 8;
                        bis.read(doub);
                        this.scale.y = doub_buf.getDouble();

                        doub_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 8;
                        bis.read(doub);
                        this.scale.z = doub_buf.getDouble();

                        doub_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 8;
                        bis.read(dword);
                        this.unused[0] = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.unused[1] = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.unused[2] = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.ques0 = dword_buf.getInt();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.ques1 = dword_buf.getInt();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.parentNodeId = dword_buf.getInt();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);


                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.bIncludeInBoundsCalc = dword_buf.getInt();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m00 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m01 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m02 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m03 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m10 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m11 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m12 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m13 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m20 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m21 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m22 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m23 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m30 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m31 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m32 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.transform.m33 = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.fImportanceFactor = dword_buf.getFloat();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;
                        bis.read(dword);
                        this.numString = dword_buf.getInt();

                        dword_buf.clear();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= 4;

                        this.name = new byte[this.numString];
                        bis.read(this.name);

                        this.name_str = new String(this.name, StandardCharsets.UTF_8);

                        StringBuilder buf = new StringBuilder(this.name_str.length());

                        for (int i = 0; i < this.name_str.length(); i++) {
                            if (this.name_str.charAt(i) == ' ' || this.name_str.charAt(i) == '\n' || this.name_str.charAt(i) == '\t' || this.name_str.charAt(i) == '　')
                                buf.append("_");
                            else
                                buf.append(this.name_str.charAt(i));
                        }

                        this.name_str_removed = buf.toString();

                        XACData.Chunk.NodeChunk.this.rest_nodec -= this.numString;

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}